package com.corhuila.securitymongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityMongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
